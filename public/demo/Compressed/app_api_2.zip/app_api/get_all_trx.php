<?php
require_once "cors.php";
require_once "db.php";

$api_key_result = $mysqli->query("SELECT * FROM info WHERE id = 1");
$api_key_row = $api_key_result->fetch_assoc();
$correct_api_key = $api_key_row["api_key"];

$api_key = isset($_SERVER["HTTP_API_KEY"]) ? $_SERVER["HTTP_API_KEY"] : "";

if ($api_key == $correct_api_key) {
    $result = $mysqli->query("SELECT * FROM active_payments");
    $all_trx = [];
    while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
        array_push($all_trx, $row);
    }
    echo json_encode($all_trx);
} else {
    $data = [];
    $data["msg"] = "Incorrect API Key!";
    echo json_encode($data);
    http_response_code(500);
}
