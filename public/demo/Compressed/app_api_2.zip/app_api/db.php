<?php
$mysqli = new mysqli("localhost", "bdcampai_loto", "bdcampai_loto", "bdcampai_loto");

if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

function executeQuery($sql, $msg)
{
    global $mysqli;
    $res = [];
    if ($mysqli->query($sql) === true) {
        $res['success'] = true;
        $res['msg'] = $msg;
    } else {
        $res['success'] = false;
        $res['err'] = $mysqli->error;
    }
    echo json_encode($res);
}
