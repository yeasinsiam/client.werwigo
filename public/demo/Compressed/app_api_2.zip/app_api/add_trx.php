<?php
require_once 'cors.php';
require_once 'db.php';

$api_key_result = $mysqli->query("SELECT * FROM info WHERE id = 1");
$api_key_row = $api_key_result->fetch_assoc();
$correct_api_key = $api_key_row['api_key'];

$api_key = isset($_SERVER['HTTP_API_KEY']) ? $_SERVER['HTTP_API_KEY'] : '';

if ($api_key == $correct_api_key) {

    $mysqli->begin_transaction();

    $json_data = file_get_contents("php://input");
    $active_payments_array = json_decode($json_data, true);

    if (empty($active_payments_array)) {
        $data = [];
        $data['msg'] = 'No data to save!';
        echo json_encode($data);
        http_response_code(500);
        exit();
    }

    foreach ($active_payments_array as $active_payments_object) {
        $main_balance = $active_payments_object['main_balance'];
        $amount = $active_payments_object['amount'];
        $transaction_id = $active_payments_object['transaction_id'];
        $sender_number = $active_payments_object['sender_number'];
        $payment_method = $active_payments_object['payment_method'];
        
        $insert_result = $mysqli->query("INSERT INTO active_payments (main_balance, amount, transaction_id, sender_number, payment_method) VALUES ('$main_balance', '$amount', '$transaction_id', '$sender_number', '$payment_method')");
        
        if (!$insert_result) {
            $mysqli->rollback();
            $data = [];
            $data['msg'] = 'Failed to save data!';
            echo json_encode($data);
            http_response_code(500);
            exit();
        }
    }

    if ($mysqli->affected_rows == count($active_payments_array)) {
        $mysqli->commit();
        $data = [];
        $data['msg'] = 'Data saved successfully!';
        echo json_encode($data);
    } else {
        $mysqli->rollback();
        $data = [];
        $data['msg'] = 'Failed to save data!';
        echo json_encode($data);
        http_response_code(500);
    }

} else {
    $data = [];
    $data['msg'] = 'Incorrect API Key!';
    echo json_encode($data);
    http_response_code(500);
}