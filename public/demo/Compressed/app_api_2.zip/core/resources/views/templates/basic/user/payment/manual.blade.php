@extends($activeTemplate.'layouts.master')

@section('content')
<?php $ph = App\Models\Gateway::where('code',$data->method_code)->first(); ?>

<section class="pt-100 pb-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card card-deposit custom__bg">
                    
                    <div class="card-body  ">
                        <form action="{{ route('user.deposit.manual.update') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <p class="text-center mt-2">@lang('You have requested') <b class="text-success">{{ showAmount($data['amount'])  }} {{__($general->cur_text)}}</b> , @lang('Please pay')
                                        <b class="text-success">{{showAmount($data['final_amo']) .' '.$data['method_currency'] }} </b> @lang('for successful payment')
                                    </p>
                                    <h4 class="text-center mb-4">@lang('Please follow the instruction below')</h4>

                                    <p class="my-4 text-center">@php echo  $data->gateway->description @endphp</p>

                                </div>
                                @if($ph->gate == 0)
                                <input type="hidden" name="method_code" value="{{$data->method_code}}"> 
                                <x-viser-form identifier="id" identifierValue="{{ $gateway->form_id }}" />
                                @else
                                <input type="hidden" name="method_code" value="{{$data->method_code}}"> 
                                 <div class="col-md-12">
                                    <div class="form-group">
                                        <label><strong>Enter Your {{ $data->gateway->name }} Number<span class="text-danger">*</span></strong></label>
                                        <input type="text" class="form-control form-control-lg" name="number" value="{{ old('number') }}" placeholder="Enter Your {{ $data->gateway->name }} Number">
                                        
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label><strong>Enter Your {{ $data->gateway->name }} Transaction Id<span class="text-danger">*</span></strong></label>
                                        <input type="text" class="form-control form-control-lg" name="tran" value="{{ old('tran') }}" placeholder="Enter Your {{ $data->gateway->name }} Transaction Id">
                                    </div>
                                </div>
                                @endif
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn--base w-100">@lang('Pay Now')</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <
@endsection
