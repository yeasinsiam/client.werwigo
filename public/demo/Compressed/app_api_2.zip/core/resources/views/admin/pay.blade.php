@extends('admin.layouts.app')

@section('panel')
<div class="row">

    <div class="col-lg-12">
        <div class="card">
            <div class="table-responsive--sm">
                <table class="table table--light style--two">
                    <thead>
                        <tr>
                            <th scope="col">@lang('Name')</th>
                            <th scope="col">@lang('Sender Number')</th>
                            <th scope="col">@lang('Transaction Id')</th>
                            <th scope="col">@lang('Amount')</th>
                            <th scope="col">@lang('Main balance')</th>
                            <th scope="col">@lang('status')</th>
                            <th scope="col">@lang('Action')</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($plans as $plan)
                        <tr>
                            <td data-label="@lang('Name')">{{$plan->payment_method}}</td>
                            <td data-label="@lang('senter Number')" class="font-weight-bold">{{ $plan->sender_number }}</td>     

                            <td data-label="@lang('Trx Id')">{{ $plan->transaction_id}}</td>
                            <td data-label="@lang('Amount')"> {{ $plan->amount }} </td>
                            <td data-label="@lang('Main Balance')"> {{ $plan->main_balance }} </td>
                            <td data-label="@lang('Status')">
                                    @if($plan->status == "Active")
                                <span class="badge badge--success font-weight-normal text--small">
                                    @lang('active')
                                </span>
                                    @else
                                    <span class="badge badge--danger font-weight-normal text--small">
                                    @lang('inactive')
                                </span>

                                    @endif
                                </span>
                            </td>
                            <td data-label="@lang('Action')"> 
                                <button class="icon-btn editBtn" data-id="{{ $plan->id }}" data-name="{{ $plan->payment_method }}" data-status="{{ $plan->status }}" data-sender_number="{{ $plan->sender_number }}" data-transaction_id="{{ $plan->transaction_id }}" data-amount="{{ $plan->amount }}" data-act="Edit">
                                    <i class="la la-pencil"></i>
                                </button>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td class="text-muted text-center" colspan="100%">{{ $emptyMessage }}</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if ($plans->hasPages())
            <div class="card-footer py-4">
                @php echo paginateLinks($plans) @endphp
            </div>
            @endif
        </div>
    </div>
</div>

{{-- EDIT/ADD MODAL --}}
<div id="editModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><span class="act"></span> @lang('Add Data')</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{ route('admin.pay.update') }}" method="POST">
                @csrf
                <input type="hidden" name="id">
                <div class="modal-body">

                    <div class="form-group">
                        <label for="name"><strong>@lang('Name') :</strong> </label>
                        <input type="text" class="form-control" name="payment_method" placeholder="@lang('Plan Name')" required>
                    </div>
                    <div class="form-group">
                        <label for="price"><strong>@lang('Amount') :</strong> </label>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control has-append" name="amount" placeholder="@lang('Price of Plan')" required>
                            
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="name"><strong>@lang('Transacction Id') :</strong> </label>
                        <input type="text" class="form-control" name="transaction_id" placeholder="@lang('Daily Earn')" required>
                    </div>
                    <div class="form-group">
                        <label for="name"><strong>@lang('Sender Number') :</strong> </label>
                        <input type="text" class="form-control" name="sender_number" placeholder="@lang('Sender Number')" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="status"><strong>@lang('Status :')</strong> </label>
                        <select name="status" class="form-control">
                            <option value="Pending">Pending</option>
                            <option value="Active">Active</option>
                        </select>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
                    <button type="submit" class="btn btn--primary">@lang('Submit')</button>
                </div>
            </form>
        </div>
    </div>
</div>


@endsection

@push('breadcrumb-plugins')
<button class="icon-btn editBtn" data-id="0" data-act="Add"><i class="fa fa-fw fa-plus"></i>Add New</button>
@endpush


@push('script')
<script>
    (function($){
        "use strict";
        $('.editBtn').on('click', function() {
            var modal = $('#editModal');
            modal.find('.act').text($(this).data('act'));
            modal.find('input[name=id]').val($(this).data('id'));
            modal.find('input[name=payment_method]').val($(this).data('name'));
            modal.find('input[name=amount]').val($(this).data('amount'));
            modal.find('input[name=transaction_id]').val($(this).data('transaction_id'));
            modal.find('input[name=sender_number]').val($(this).data('sender_number'));
            modal.find('select[name=status]').val($(this).data('status'));
            modal.modal('show');
        });
    })(jQuery);
</script>
@endpush