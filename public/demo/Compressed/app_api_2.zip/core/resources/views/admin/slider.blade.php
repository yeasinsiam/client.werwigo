@extends('admin.layouts.app')

@section('panel')
<div class="row">
<div class="col-lg-12">
    
</div>
    <div class="col-lg-12">
        <form method="post" action="{{ route('admin.notice') }}">
        @csrf
    <div class="form-group">
        <label>@lang('Notice Add')</label>
        <div class="input-group">
            <input class="form--control" name="name" type="text" value="{{ $no->name }}">
        </div>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-success">Update</button>
    </div>
    </form>
        <div class="card">
            <div class="table-responsive--sm">
                <table class="table table--light style--two">
                    <thead>
                        <tr>
                            <th scope="col">@lang('Image')</th>
                            <th scope="col">@lang('Image Type')</th>
                            
                            <th scope="col">@lang('Action')</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($plans as $plan)
                        <tr>
                            <td data-label="@lang('Image')"><img src="{{ url('') }}/{{$plan->image}}" style="width: 118px;"></td>
                            
                            <td data-label="@lang('Status')">
                                    @if($plan->status == "1")
                                <span class="badge badge--success font-weight-normal text--small">
                                    @lang('Mini Image')
                                </span>
                                    @else
                                    <span class="badge badge--danger font-weight-normal text--small">
                                    @lang('Main Image')
                                </span>

                                    @endif
                                </span>
                            </td>
                            <td data-label="@lang('Action')"> 
                                <button class="icon-btn editBtn" data-id="{{ $plan->id }}" data-type="{{ $plan->type }}" data-image="{{ $plan->image }}" data-act="Edit">
                                    <i class="la la-pencil"></i>
                                </button>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td class="text-muted text-center" colspan="100%">{{ $emptyMessage }}</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if ($plans->hasPages())
            <div class="card-footer py-4">
                @php echo paginateLinks($plans) @endphp
            </div>
            @endif
        </div>
    </div>
</div>

{{-- EDIT/ADD MODAL --}}
<div id="editModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><span class="act"></span> @lang('Add Data')</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="id">
                <div class="modal-body">
                    
                    <div class="form-group">
                        <label for="name"><strong>@lang('Image') :</strong> </label>
                        <input type="file" class="form-control" name="image" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="status"><strong>@lang('Image type :')</strong> </label>
                        <select name="type" class="form-control">
                            <option value="1">Mini Image</option>
                            <!--<option value="2">Main Image</option>-->
                        </select>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
                    <button type="submit" class="btn btn--primary">@lang('Submit')</button>
                </div>
            </form>
        </div>
    </div>
</div>


@endsection

@push('breadcrumb-plugins')

<button class="icon-btn editBtn" data-id="0" data-act="Add"><i class="fa fa-fw fa-plus"></i>Add New Slider</button>
@endpush


@push('script')
<script>
    (function($){
        "use strict";
        $('.editBtn').on('click', function() {
            var modal = $('#editModal');
            modal.find('.act').text($(this).data('act'));
            modal.find('input[name=id]').val($(this).data('id'));
            //modal.find('input[name=image]').val($(this).data('image'));
            modal.find('select[name=type]').val($(this).data('type'));
            modal.modal('show');
        });
    })(jQuery);
</script>
@endpush