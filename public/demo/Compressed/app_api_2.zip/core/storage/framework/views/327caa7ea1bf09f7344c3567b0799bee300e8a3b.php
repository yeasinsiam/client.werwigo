

<?php $__env->startSection('panel'); ?>
<div class="row">

    <div class="col-lg-12">
        <div class="card">
            <div class="table-responsive--sm">
                <table class="table table--light style--two">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Name'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Sender Number'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Transaction Id'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Main balance'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('status'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('Name'); ?>"><?php echo e($plan->payment_method); ?></td>
                            <td data-label="<?php echo app('translator')->get('senter Number'); ?>" class="font-weight-bold"><?php echo e($plan->sender_number); ?></td>     

                            <td data-label="<?php echo app('translator')->get('Trx Id'); ?>"><?php echo e($plan->transaction_id); ?></td>
                            <td data-label="<?php echo app('translator')->get('Amount'); ?>"> <?php echo e($plan->amount); ?> </td>
                            <td data-label="<?php echo app('translator')->get('Main Balance'); ?>"> <?php echo e($plan->main_balance); ?> </td>
                            <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($plan->status == "Active"): ?>
                                <span class="badge badge--success font-weight-normal text--small">
                                    <?php echo app('translator')->get('active'); ?>
                                </span>
                                    <?php else: ?>
                                    <span class="badge badge--danger font-weight-normal text--small">
                                    <?php echo app('translator')->get('inactive'); ?>
                                </span>

                                    <?php endif; ?>
                                </span>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Action'); ?>"> 
                                <button class="icon-btn editBtn" data-id="<?php echo e($plan->id); ?>" data-name="<?php echo e($plan->payment_method); ?>" data-status="<?php echo e($plan->status); ?>" data-sender_number="<?php echo e($plan->sender_number); ?>" data-transaction_id="<?php echo e($plan->transaction_id); ?>" data-amount="<?php echo e($plan->amount); ?>" data-act="Edit">
                                    <i class="la la-pencil"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-muted text-center" colspan="100%"><?php echo e($emptyMessage); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($plans->hasPages()): ?>
            <div class="card-footer py-4">
                <?php echo paginateLinks($plans) ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<div id="editModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><span class="act"></span> <?php echo app('translator')->get('Add Data'); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('admin.pay.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-body">

                    <div class="form-group">
                        <label for="name"><strong><?php echo app('translator')->get('Name'); ?> :</strong> </label>
                        <input type="text" class="form-control" name="payment_method" placeholder="<?php echo app('translator')->get('Plan Name'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="price"><strong><?php echo app('translator')->get('Amount'); ?> :</strong> </label>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control has-append" name="amount" placeholder="<?php echo app('translator')->get('Price of Plan'); ?>" required>
                            
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="name"><strong><?php echo app('translator')->get('Transacction Id'); ?> :</strong> </label>
                        <input type="text" class="form-control" name="transaction_id" placeholder="<?php echo app('translator')->get('Daily Earn'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="name"><strong><?php echo app('translator')->get('Sender Number'); ?> :</strong> </label>
                        <input type="text" class="form-control" name="sender_number" placeholder="<?php echo app('translator')->get('Sender Number'); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="status"><strong><?php echo app('translator')->get('Status :'); ?></strong> </label>
                        <select name="status" class="form-control">
                            <option value="Pending">Pending</option>
                            <option value="Active">Active</option>
                        </select>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
<button class="icon-btn editBtn" data-id="0" data-act="Add"><i class="fa fa-fw fa-plus"></i>Add New</button>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
<script>
    (function($){
        "use strict";
        $('.editBtn').on('click', function() {
            var modal = $('#editModal');
            modal.find('.act').text($(this).data('act'));
            modal.find('input[name=id]').val($(this).data('id'));
            modal.find('input[name=payment_method]').val($(this).data('name'));
            modal.find('input[name=amount]').val($(this).data('amount'));
            modal.find('input[name=transaction_id]').val($(this).data('transaction_id'));
            modal.find('input[name=sender_number]').val($(this).data('sender_number'));
            modal.find('select[name=status]').val($(this).data('status'));
            modal.modal('show');
        });
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bdcampai/public_html/core/resources/views/admin/pay.blade.php ENDPATH**/ ?>