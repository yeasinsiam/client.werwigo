<?php echo  loadExtension('tawk-chat') ?>
<?php echo  loadExtension('google-analytics') ?>
<?php /**PATH /home/bdcampai/public_html/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>