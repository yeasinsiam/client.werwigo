

<?php $__env->startSection('panel'); ?>
<div class="row">
<div class="col-lg-12">
    
</div>
    <div class="col-lg-12">
        <form method="post" action="<?php echo e(route('admin.notice')); ?>">
        <?php echo csrf_field(); ?>
    <div class="form-group">
        <label><?php echo app('translator')->get('Notice Add'); ?></label>
        <div class="input-group">
            <input class="form--control" name="name" type="text" value="<?php echo e($no->name); ?>">
        </div>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-success">Update</button>
    </div>
    </form>
        <div class="card">
            <div class="table-responsive--sm">
                <table class="table table--light style--two">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('Image'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('Image Type'); ?></th>
                            
                            <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('Image'); ?>"><img src="<?php echo e(url('')); ?>/<?php echo e($plan->image); ?>" style="width: 118px;"></td>
                            
                            <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($plan->status == "1"): ?>
                                <span class="badge badge--success font-weight-normal text--small">
                                    <?php echo app('translator')->get('Mini Image'); ?>
                                </span>
                                    <?php else: ?>
                                    <span class="badge badge--danger font-weight-normal text--small">
                                    <?php echo app('translator')->get('Main Image'); ?>
                                </span>

                                    <?php endif; ?>
                                </span>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Action'); ?>"> 
                                <button class="icon-btn editBtn" data-id="<?php echo e($plan->id); ?>" data-type="<?php echo e($plan->type); ?>" data-image="<?php echo e($plan->image); ?>" data-act="Edit">
                                    <i class="la la-pencil"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-muted text-center" colspan="100%"><?php echo e($emptyMessage); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($plans->hasPages()): ?>
            <div class="card-footer py-4">
                <?php echo paginateLinks($plans) ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<div id="editModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><span class="act"></span> <?php echo app('translator')->get('Add Data'); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-body">
                    
                    <div class="form-group">
                        <label for="name"><strong><?php echo app('translator')->get('Image'); ?> :</strong> </label>
                        <input type="file" class="form-control" name="image" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="status"><strong><?php echo app('translator')->get('Image type :'); ?></strong> </label>
                        <select name="type" class="form-control">
                            <option value="1">Mini Image</option>
                            <!--<option value="2">Main Image</option>-->
                        </select>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>

<button class="icon-btn editBtn" data-id="0" data-act="Add"><i class="fa fa-fw fa-plus"></i>Add New Slider</button>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
<script>
    (function($){
        "use strict";
        $('.editBtn').on('click', function() {
            var modal = $('#editModal');
            modal.find('.act').text($(this).data('act'));
            modal.find('input[name=id]').val($(this).data('id'));
            //modal.find('input[name=image]').val($(this).data('image'));
            modal.find('select[name=type]').val($(this).data('type'));
            modal.modal('show');
        });
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bdcampai/public_html/core/resources/views/admin/slider.blade.php ENDPATH**/ ?>