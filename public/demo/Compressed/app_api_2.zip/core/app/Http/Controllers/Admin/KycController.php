<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Form;
use App\Lib\FormProcessor;
use Illuminate\Http\Request;
use App\Models\active_payment;
use App\Models\Notice;
use App\Models\Slider;
use Image;
use App\Rules\FileTypeValidate;

class KycController extends Controller
{
    public function setting()
    {
        $pageTitle = 'KYC Setting';
        $form = Form::where('act','kyc')->first();
        return view('admin.kyc.setting',compact('pageTitle','form'));
    }

    public function settingUpdate(Request $request)
    {
        $formProcessor = new FormProcessor();
        $generatorValidation = $formProcessor->generatorValidation();
        $request->validate($generatorValidation['rules'],$generatorValidation['messages']);
        $exist = Form::where('act','kyc')->first();
        if ($exist) {
            $isUpdate = true;
        }else{
            $isUpdate = false;
        }
        $formProcessor->generate('kyc',$isUpdate,'act');

        $notify[] = ['success','KYC data updated successfully'];
        return back()->withNotify($notify);
    }
    
    public function notice(Request $request)
    {
        $no = Notice::first();
        $no->name = $request->name;
        $no->save();
        $notify[] = ['success', 'Notice has been Updated Successfully.'];
        return back()->withNotify($notify);
    }
    
    public function pay()
    {
        $pageTitle = 'Manage Vallypay';
        $emptyMessage = 'No Data Stored Yet.';
        $plans = active_payment::orderBy('id','desc')->paginate(getPaginate());
        
        return view('admin.pay', compact('pageTitle', 'emptyMessage', 'plans'));
    }
    
    public function slider()
    {
        $pageTitle = 'Manage Slider';
        $emptyMessage = 'No Slider Created Yet.';
        $plans = Slider::orderBy('id','desc')->paginate(getPaginate());
        $no = Notice::first();
        return view('admin.slider', compact('pageTitle', 'emptyMessage', 'plans','no'));
    }
    
    public function sliderupdate(Request $request) {

        $request->validate([
            'image' => 'required',
            'type' => 'required',
            
        ]);

        if($request->id == 0){
            $plan = new Slider();
        }else{
            $plan = Slider::findOrFail($request->id);
        }
        $fileName = time() . '.' . $request->image->extension();
        // $path = getFilePath('slider');
        // if (!file_exists($path)) {
        //     mkdir($path, 0755, true);
        // }
        // Image::make($request->image)->save($path . '/$fileName');
        $request->image->move(public_path('image'), $fileName);
        $plan->image = "/core/public/image/".$fileName;
        
        $plan->type = $request->type;
        $plan->save();
        
        $notify[] = ['success', 'Slider has been Updated Successfully.'];
        return back()->withNotify($notify);
    }
    
    
    public function payupdate(Request $request) {

        $request->validate([
            'payment_method' => 'required',
            'amount' => 'required|numeric|min:0',
            
        ]);

        if($request->id == 0){
            $plan = new active_payment();
        }else{
            $plan = active_payment::findOrFail($request->id);
        }
        
        $plan->payment_method = $request->payment_method;
        $plan->sender_number = $request->sender_number;
        $plan->transaction_id = $request->transaction_id;
        $plan->amount = $request->amount;
        $plan->status = $request->status;
        $plan->save();
        
        $notify[] = ['success', 'Vallypay has been Updated Successfully.'];
        return back()->withNotify($notify);
    }
}
