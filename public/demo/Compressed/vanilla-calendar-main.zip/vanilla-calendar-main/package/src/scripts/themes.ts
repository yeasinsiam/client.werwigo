const themes = ['light', 'dark', 'system'] as const;

export default themes;
